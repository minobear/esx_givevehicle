Locales['tw'] = {
	['gived_car'] = '已將 ~y~%s ~s~車牌為~y~ %s ~s~的車分配給 ~g~%s',
	['received_car'] = '你已收到一台車牌為 ~y~%s ~s~的車, 快去車庫看看吧!',
	['del_car'] = '已刪除一台車牌為 ~y~%s ~s~的車',	
	['none_plate'] = '~r~必須打上此台車的自訂車牌',		
	['unknown_car'] = '~r~未知的車輛',
	['plate_already_have'] = '~r~此車牌已經有車輛擁有了, 請換一個車牌'
}