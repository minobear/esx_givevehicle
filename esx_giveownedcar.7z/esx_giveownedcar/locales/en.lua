Locales['en'] = {
	['gived_car'] = 'Vehicle ~y~%s ~s~with plate number ~y~ %s ~s~has been park into ~g~%s~s~\'s garage',
	['received_car'] = 'You received a vehicle with plate number ~y~%s',
	['del_car'] = 'Has deleted a vehicle with plate number ~y~%s',	
	['none_plate'] = '~r~You need type a custom plate',		
	['unknown_car'] = '~r~Unknown car name',
	['plate_already_have'] = '~r~This plate is already been used on another vehicle'
}