Config = {}
Config.Locale = 'en' -- en, tw

Config.ReceiveMsg = true